package com.biletaluygulamasi.bilet_al;

import android.support.v7.app.AppCompatActivity;


public class IletisimActivity extends AppCompatActivity {









}
