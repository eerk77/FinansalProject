package com.biletaluygulamasi.bilet_al;

/**
 * Created by orkun on 1.05.2018.
 */

public class Flower {

    public String name;
    public String surname;

public Flower (String name,String surname)
{
    this.name = name;
    this.surname = surname;
}


}
